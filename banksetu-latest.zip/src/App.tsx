import { useEffect, useRef, useState } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  type User,
} from "firebase/auth";
import { doc, getDoc, onSnapshot, type Unsubscribe } from "firebase/firestore";

import { auth, db } from "./firebase";
import Dashboard from "./Dashboard";
import Signup from "./Signup";

import "./App.css";

type BankSetuRole = "admin" | "user";
type UserProfile = {
  role?: string;
  status?: string;
  subscriptionStatus?: string;
  email?: string;
};

const normalize = (value: unknown) => String(value ?? "").trim().toLowerCase();

function getAccessError(profile: UserProfile): string {
  const status = normalize(profile.status);
  const subscriptionStatus = normalize(profile.subscriptionStatus);

  if (status === "blocked") {
    return "Your Bank Setu account has been blocked by the administrator.";
  }

  if (status !== "approved") {
    return "Your registration is pending administrator approval.";
  }

  if (subscriptionStatus !== "active") {
    return "Your subscription is inactive. Please contact the administrator.";
  }

  return "";
}

function App() {
  const [screen, setScreen] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<BankSetuRole>("user");

  const loginAttemptRef = useRef(false);
  const profileUnsubscribeRef = useRef<Unsubscribe | null>(null);

  const clearProfileListener = () => {
    if (profileUnsubscribeRef.current) {
      profileUnsubscribeRef.current();
      profileUnsubscribeRef.current = null;
    }
  };

  const applyProfile = (profile: UserProfile) => {
    const role: BankSetuRole = normalize(profile.role) === "admin" ? "admin" : "user";
    setUserRole(role);
    sessionStorage.setItem("bankSetuRole", role);
    return role;
  };

  const rejectSession = async (message: string) => {
    clearProfileListener();
    sessionStorage.removeItem("bankSetuRole");
    setUserRole("user");
    setIsLoggedIn(false);
    setLoginSuccess(false);
    setError(message);

    if (auth.currentUser) {
      try {
        await signOut(auth);
      } catch (signOutError) {
        console.error("Sign out after access rejection failed:", signOutError);
      }
    }
  };

  const watchUserProfile = (user: User) => {
    clearProfileListener();

    const userRef = doc(db, "users", user.uid);
    profileUnsubscribeRef.current = onSnapshot(
      userRef,
      async (snapshot) => {
        if (!snapshot.exists()) {
          await rejectSession(
            "Your Bank Setu profile was not found. Please contact the administrator."
          );
          setCheckingSession(false);
          return;
        }

        const profile = snapshot.data() as UserProfile;
        applyProfile(profile);

        const accessError = getAccessError(profile);
        if (accessError) {
          await rejectSession(accessError);
          setCheckingSession(false);
          return;
        }

        if (!loginAttemptRef.current) {
          setError("");
          setIsLoggedIn(true);
        }

        setCheckingSession(false);
      },
      async (snapshotError) => {
        console.error("Profile listener error:", snapshotError);
        await rejectSession("Unable to verify your account permissions.");
        setCheckingSession(false);
      }
    );
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (!user) {
        clearProfileListener();
        setIsLoggedIn(false);
        setCheckingSession(false);
        return;
      }

      setCheckingSession(true);
      watchUserProfile(user);
    });

    return () => {
      unsubscribe();
      clearProfileListener();
    };
  }, []);

  const handleForgotPassword = async () => {
    setError("");
    setSuccessMessage("");

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setError("Please enter your email address first.");
      return;
    }

    try {
      setResetLoading(true);
      await sendPasswordResetEmail(auth, cleanEmail);
      setSuccessMessage(
        "Password reset link sent. Please check your email inbox or spam folder."
      );
    } catch (err: any) {
      console.error("Password reset error:", err);

      if (err.code === "auth/invalid-email") {
        setError("Please enter a valid email address.");
      } else if (err.code === "auth/too-many-requests") {
        setError("Too many requests. Please try again later.");
      } else if (err.code === "auth/network-request-failed") {
        setError("Internet connection problem. Please try again.");
      } else {
        setError("Unable to send the password reset email. Please try again.");
      }
    } finally {
      setResetLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");
    loginAttemptRef.current = true;

    if (!email.trim() || !password.trim()) {
      setError("Please enter your email and password.");
      loginAttemptRef.current = false;
      return;
    }

    try {
      setLoading(true);

      const credential = await signInWithEmailAndPassword(
        auth,
        email.trim(),
        password
      );

      const userRef = doc(db, "users", credential.user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        await rejectSession(
          "Your Bank Setu profile was not found. Please contact the administrator."
        );
        return;
      }

      const userData = userSnap.data() as UserProfile;
      applyProfile(userData);

      const accessError = getAccessError(userData);
      if (accessError) {
        await rejectSession(accessError);
        return;
      }

      setLoginSuccess(true);
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setIsLoggedIn(true);
      setLoginSuccess(false);
    } catch (err: any) {
      console.error("Login error:", err);

      if (err.code === "auth/user-disabled") {
        setError("Your Bank Setu account has been blocked by the administrator.");
      } else if (err.code === "auth/invalid-credential") {
        setError("Invalid email or password.");
      } else if (err.code === "auth/too-many-requests") {
        setError("Too many login attempts. Please try again later.");
      } else if (err.code === "auth/network-request-failed") {
        setError("Internet connection problem. Please try again.");
      } else if (err.code === "permission-denied") {
        setError("Bank Setu could not verify your account permissions.");
      } else {
        setError(`Login failed: ${err.code || "unknown-error"}`);
      }
    } finally {
      loginAttemptRef.current = false;
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      clearProfileListener();
      await signOut(auth);
      sessionStorage.removeItem("bankSetuRole");
      setIsLoggedIn(false);
      setUserRole("user");
      setEmail("");
      setPassword("");
      setError("");
      setSuccessMessage("");
      setLoginSuccess(false);
      setScreen("login");
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  if (checkingSession) {
    return (
      <main className="app-loader">
        <div className="loader-logo">
          <span className="loader-bank">B</span>
          <span className="loader-setu">S</span>
        </div>
        <p>Loading Bank Setu...</p>
      </main>
    );
  }

  if (loginSuccess) {
    return (
      <main className="login-success-page">
        <div className="login-success-card">
          <div className="login-success-check">✓</div>
          <h2>Login Successful</h2>
          <p>Opening your Bank Setu dashboard...</p>
        </div>
      </main>
    );
  }

  if (isLoggedIn) {
    return (
      <div className={`banksetu-session banksetu-role-${userRole}`}>
        <Dashboard onLogout={handleLogout} userRole={userRole} />
      </div>
    );
  }

  if (screen === "signup") {
    return (
      <Signup
        onBackToLogin={() => {
          setScreen("login");
          setError("");
          setSuccessMessage(
            "New accounts can sign in after administrator approval."
          );
        }}
      />
    );
  }

  return (
    <main className="login-page">
      <div className="ambient ambient-one"></div>
      <div className="ambient ambient-two"></div>

      <section className="login-shell">
        <div className="login-card">
          <div className="banksetu-logo" aria-label="Bank Setu">
            <div className="logo-ring">
              <div className="logo-bridge">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>

          <div className="brand">
            <h1>
              BANK <span>SETU</span>
            </h1>
          </div>

          <div className="welcome">
            <h2>Welcome back</h2>
          </div>

          <form onSubmit={handleLogin}>
            <div className="field">
              <label>Email address</label>
              <div className="input-box">
                <div className="field-icon">✉</div>
                <input
                  type="email"
                  placeholder="name@example.com"
                  autoComplete="username"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="field">
              <div className="field-label-row">
                <label>Password</label>
                <button
                  type="button"
                  className="forgot-link"
                  onClick={handleForgotPassword}
                  disabled={resetLoading}
                >
                  {resetLoading ? "Sending..." : "Forgot password?"}
                </button>
              </div>

              <div className="input-box">
                <div className="field-icon">●</div>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            {error && (
              <div className="form-message error-message">
                <span>!</span>
                {error}
              </div>
            )}

            {successMessage && (
              <div className="form-message success-message">
                <span>✓</span>
                {successMessage}
              </div>
            )}

            <div className="login-options">
              <label className="remember">
                <input type="checkbox" />
                <span>Keep me signed in</span>
              </label>
              <span className="encrypted">● Secure</span>
            </div>

            <div className="auth-action-row">
              <button className="sign-in" type="submit" disabled={loading}>
                <span>{loading ? "Signing in..." : "Sign In"}</span>
                {!loading && <span className="arrow">→</span>}
              </button>

              <button
                type="button"
                className="create-account-button"
                onClick={() => {
                  setScreen("signup");
                  setError("");
                  setSuccessMessage("");
                }}
              >
                Create Account
              </button>
            </div>
          </form>

          <p className="approval-note compact-approval-note">
            New registrations require administrator approval.
          </p>

          <div className="login-footer">
            <span className="status-dot"></span>
            Bank Setu Secure Access
            <span className="footer-separator">•</span>
            v1.0
          </div>
        </div>
      </section>
    </main>
  );
}

export default App;